"""Thin ctypes binding for libmarginalia (crates/ffi).

    from marginalia import Document
    with Document.open("book.epub") as doc:
        print(doc.call("summary")["info"]["title"])
        hits = doc.call("search", {"query": "clocks"})
        anchor = doc.call("createAnchor", {"unit": 0, "start": 10, "end": 20})

    print(parse_note("see [the clocks](ann:a1) and https://x.org"))

Opening a path reads the file in place (only indexes and what is being read
are in memory); keep the file where it is until the document is closed.
Offsets are Unicode code points (Python str indices) by default.

The library is looked for in this order: $MARGINALIA_LIB, next to this file
(the installed wheel ships it there), then the system loader path.
"""
import ctypes
import json
import os
import sys

_name = {"darwin": "libmarginalia.dylib", "win32": "marginalia.dll"}.get(sys.platform, "libmarginalia.so")


def _load():
    if os.environ.get("MARGINALIA_LIB"):
        return ctypes.CDLL(os.environ["MARGINALIA_LIB"])
    here = os.path.join(os.path.dirname(os.path.abspath(__file__)), _name)
    return ctypes.CDLL(here if os.path.exists(here) else _name)


_lib = _load()
_c = ctypes.c_char_p
_lib.mg_version.restype = _c
_lib.mg_open.restype = ctypes.c_void_p
_lib.mg_open.argtypes = [ctypes.c_char_p, ctypes.c_size_t, _c, ctypes.c_bool, ctypes.POINTER(ctypes.c_void_p)]
_lib.mg_open_path.restype = ctypes.c_void_p
_lib.mg_open_path.argtypes = [_c, _c, ctypes.c_bool, ctypes.POINTER(ctypes.c_void_p)]
_lib.mg_close.argtypes = [ctypes.c_void_p]
_lib.mg_call.restype = ctypes.c_bool
_lib.mg_call.argtypes = [ctypes.c_void_p, _c, _c, ctypes.POINTER(ctypes.c_void_p)]
_lib.mg_call_static.restype = ctypes.c_bool
_lib.mg_call_static.argtypes = [_c, _c, ctypes.POINTER(ctypes.c_void_p)]
_lib.mg_resource.restype = ctypes.c_void_p
_lib.mg_resource.argtypes = [ctypes.c_void_p, _c, ctypes.POINTER(ctypes.c_size_t), ctypes.POINTER(ctypes.c_void_p)]
_lib.mg_free_string.argtypes = [ctypes.c_void_p]
_lib.mg_free_bytes.argtypes = [ctypes.c_void_p, ctypes.c_size_t]


def _take(p):
    if not p:
        return None
    try:
        return ctypes.string_at(p).decode("utf-8")
    finally:
        _lib.mg_free_string(p)


class MarginaliaError(Exception):
    def __init__(self, payload):
        err = json.loads(payload)["error"]
        super().__init__(f'{err["code"]}: {err["message"]}')
        self.code = err["code"]


class Document:
    def __init__(self, handle):
        self._h = handle

    @classmethod
    def open(cls, path_or_bytes, password=None, utf16=False):
        """Open a PDF or EPUB from a path (read in place) or from bytes."""
        err = ctypes.c_void_p()
        pw = password.encode() if password else None
        if isinstance(path_or_bytes, (bytes, bytearray, memoryview)):
            data = bytes(path_or_bytes)
            h = _lib.mg_open(data, len(data), pw, utf16, ctypes.byref(err))
        else:
            h = _lib.mg_open_path(os.fsencode(os.fspath(path_or_bytes)), pw, utf16, ctypes.byref(err))
        if not h:
            raise MarginaliaError(_take(err.value))
        return cls(h)

    def call(self, method, args=None):
        out = ctypes.c_void_p()
        ok = _lib.mg_call(self._h, method.encode(), json.dumps(args or {}).encode(), ctypes.byref(out))
        payload = _take(out.value)
        if not ok:
            raise MarginaliaError(payload)
        return json.loads(payload)

    def resource(self, path):
        n = ctypes.c_size_t()
        mt = ctypes.c_void_p()
        p = _lib.mg_resource(self._h, path.encode(), ctypes.byref(n), ctypes.byref(mt))
        if not p:
            raise KeyError(path)
        try:
            return ctypes.string_at(p, n.value), _take(mt.value)
        finally:
            _lib.mg_free_bytes(p, n.value)

    def close(self):
        if self._h:
            _lib.mg_close(self._h)
            self._h = None

    def __enter__(self):
        return self

    def __exit__(self, *exc):
        self.close()

    __del__ = close


def version():
    return _lib.mg_version().decode()


def call_static(method, args=None):
    """Call a method that needs no document (see docs/API.md, "Links inside notes")."""
    out = ctypes.c_void_p()
    ok = _lib.mg_call_static(method.encode(), json.dumps(args or {}).encode(), ctypes.byref(out))
    payload = _take(out.value)
    if not ok:
        raise MarginaliaError(payload)
    return json.loads(payload)


def parse_note(note):
    """Note markup -> segments: {"kind": "text", "text"} | {"kind": "link", "label", "target"}."""
    return call_static("noteParse", {"note": note})


def serialize_note(segments):
    """Segments -> note markup (inverse of parse_note)."""
    return call_static("noteSerialize", {"segments": segments})


def note_targets(note):
    """Distinct link targets: {"type": "annotation", "id"} | {"type": "url", "href"}."""
    return call_static("noteTargets", {"note": note})
