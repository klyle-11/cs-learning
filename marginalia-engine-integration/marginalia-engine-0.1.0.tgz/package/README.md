# marginalia-engine

The Marginalia document engine for JavaScript: open PDF and EPUB files and get
their text (with a box for every character on PDF pages), search, the table of
contents, durable highlight anchors, an annotation store, a note-link grammar
and OCR for scanned pages. Rust compiled to WebAssembly; files are read in
place, not loaded whole.

- **`AGENTS.md`** (in this package): the integration brief — rules, procedures
  with tested code, errors and a checklist. Start here, whether you are a
  person or a coding agent.
- **`API.md`** (in this package): every method, error code and data type.

## Entry points

| Import | For | API |
| --- | --- | --- |
| `marginalia-engine` | browsers (any framework) | `new Engine()` — the engine in a Web Worker, promises |
| `marginalia-engine/node` | Node ≥ 18 | `openFile(path)`, `openBytes(bytes)` → `Document`, synchronous |
| `marginalia-engine/direct` | a Web Worker of your own, Deno | `await init(); openBlob(blob)` → `Document` |
| `marginalia-engine/ocr` | browsers | `new OcrPool({ det, rec })`, `recognize(w, h, rgba)` |
| `marginalia-engine/dom` | browsers | `offsetOf`, `rangeFor`, `pointAt`, `textLength`, `invalidate`: DOM ↔ engine offsets for EPUB chapters |
| `marginalia-engine/notes` | anywhere | `parse`, `serialize`, `targets`, `plainText`, `annotationTargets`: the note-link grammar |
| `marginalia-engine/selection` | browsers | `SelectionEngine` (double-tap a word, drag handles to change the range), `pdfSurface`, `epubSurface`, `OverlayLayer` (draw highlights, hit-test taps) |
| `marginalia-engine/themes` | browsers | `Recolorer`, `pageJob`, `pdfjsToPx`, `PAGE_THEMES`: sepia/night/black PDF pages that keep pictures; `EPUB_THEME_CSS`, `setEpubTheme` |
| `marginalia-engine/ui.css` | browsers | styles for the selection, handles and highlights; `.mg-selectable`, `.mg-dark` |

```js
import { Engine } from 'marginalia-engine';

const engine = new Engine();                 // one per open document
const summary = await engine.open(file);     // File or Blob
const [hit] = await engine.search('universally acknowledged');
const anchor = await engine.createAnchor(hit.unit, hit.start, hit.end);
engine.close();
```

```js
import { openFile } from 'marginalia-engine/node';
const doc = openFile('book.epub');
console.log(doc.summary().info.title);
doc.close();
```

Offsets are UTF-16 code units (JavaScript string indices) everywhere.

For a reading interface, `AGENTS.md` section 4 has two tested classes,
`PdfReader` (pdf.js) and `EpubReader`, that combine the selection engine, the
highlight layer and page themes.

## Bundlers and CSP

- Vite: add `optimizeDeps: { exclude: ['marginalia-engine'] }` for the dev
  server; production builds need nothing.
- webpack 5: nothing to configure.
- CSP: `script-src 'self' 'wasm-unsafe-eval'; worker-src 'self'`.

The worker (`dist/worker.js`) and WebAssembly (`dist/wasm/…`) are referenced
with `new URL(…, import.meta.url)`. The OCR build (`dist/wasm-ocr/`, ≈5.8 MB)
loads only when `marginalia-engine/ocr` is used; its models (≈12 MB, from the
ocrs project) are not included.

## License

Not yet declared by the project (`UNLICENSED`).
