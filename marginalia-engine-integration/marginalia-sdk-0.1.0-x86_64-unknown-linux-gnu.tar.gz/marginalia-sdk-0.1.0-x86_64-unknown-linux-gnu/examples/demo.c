/* cc demo.c -I../../crates/ffi/include -L../../target/release -lmarginalia -o demo
 * (or, with the SDK: cc demo.c $(pkg-config --cflags --libs marginalia) -Wl,-rpath,<sdk>/lib)
 *
 * ./demo book.epub "some words"  — open in place, search, anchor the first hit. */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "marginalia.h"

/* The integer after "key": in a JSON object (enough for this demo; use a JSON library in real code). */
static long field(const char *json, const char *key) {
    char pat[32];
    snprintf(pat, sizeof pat, "\"%s\":", key);
    const char *p = strstr(json, pat);
    return p ? strtol(p + strlen(pat), NULL, 10) : -1;
}

int main(int argc, char **argv) {
    if (argc < 3) { fprintf(stderr, "usage: demo <file> <query>\n"); return 2; }
    char *err = NULL, *out = NULL;
    /* The file is read where it lies; keep it in place until mg_close. */
    MgSession *s = mg_open_path(argv[1], NULL, false, &err);
    if (!s) { fprintf(stderr, "%s\n", err); mg_free_string(err); return 1; }

    char args[512];
    snprintf(args, sizeof args, "{\"query\": \"%s\", \"maxHits\": 3}", argv[2]);
    bool ok = mg_call(s, "search", args, &out);
    printf("search: %s\n", out);
    long unit = ok ? field(out, "unit") : -1, start = field(out, "start"), end = field(out, "end");
    mg_free_string(out);

    if (unit >= 0) {
        snprintf(args, sizeof args, "{\"unit\": %ld, \"start\": %ld, \"end\": %ld}", unit, start, end);
        ok = mg_call(s, "createAnchor", args, &out);
        printf("anchor: %s %s\n", ok ? "ok" : "error", out);
        mg_free_string(out);
    }
    mg_close(s);
    printf("marginalia %s\n", mg_version());
    return 0;
}
