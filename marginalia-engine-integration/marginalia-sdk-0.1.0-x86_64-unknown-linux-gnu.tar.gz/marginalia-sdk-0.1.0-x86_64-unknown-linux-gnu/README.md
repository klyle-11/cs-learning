# Marginalia SDK (C ABI)

The Marginalia document engine as a native library: open PDF and EPUB files
and get their text (with a box for every character on PDF pages), search, the
table of contents, durable highlight anchors, an annotation store, a note-link
grammar and OCR. Usable from C, C++, Swift, Kotlin (JNI/JNA), C#, Go (cgo) —
anything that can call C.

- **`AGENTS.md`**: the integration brief — rules, procedures, errors, checklist.
- **`docs/API.md`**: every method (JSON in, JSON out), error code and data type.
- **`docs/INTEGRATION.md`**: the guide for people, including Swift and Kotlin.

## Contents

```
include/marginalia.h            the C API (mg_open_path, mg_open, mg_call, mg_free_string, …)
lib/libmarginalia.{so,dylib,dll} the library (with OCR)
lib/pkgconfig/marginalia.pc     pkg-config file (relocatable)
bin/marginalia                  command-line tool (info, sections, text, search, anchor, …)
examples/demo.c                 open in place, search, anchor the first hit
```

## Build against it

```sh
export PKG_CONFIG_PATH=$PWD/lib/pkgconfig
cc examples/demo.c $(pkg-config --cflags --libs marginalia) -Wl,-rpath,$PWD/lib -o demo
./demo book.epub "some words"
```

```c
char *err = NULL, *out = NULL;
MgSession *s = mg_open_path("book.pdf", NULL, false, &err);   /* read in place; false = char offsets */
if (!s) { /* err is {"error":{"code":…}} */ mg_free_string(err); }
mg_call(s, "search", "{\"query\": \"some words\"}", &out);       /* JSON in, JSON out */
mg_free_string(out);
mg_close(s);
```

Strings returned by the library are freed with `mg_free_string`; panics never
cross into your code (they come back as `{"error":{"code":"panic",…}}`). The
static library (for iOS and other static links) is not included: build it with
`cargo build --release -p marginalia-ffi` from the source repository.

This SDK was built for one OS and CPU (in its file name). Build others with
`sh scripts/package.sh sdk` on (or for) the target machine.
