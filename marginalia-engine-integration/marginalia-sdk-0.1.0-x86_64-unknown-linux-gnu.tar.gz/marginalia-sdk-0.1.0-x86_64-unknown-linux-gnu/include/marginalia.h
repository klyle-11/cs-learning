/* marginalia — PDF/EPUB anchoring, annotation, sectioning and OCR.
 *
 * All strings are NUL-terminated UTF-8. Strings and buffers returned by the
 * library must be released with mg_free_string / mg_free_bytes.
 * Methods for mg_call are documented in docs/API.md (JSON in, JSON out).
 */
#ifndef MARGINALIA_H
#define MARGINALIA_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

typedef struct MgSession MgSession;

const char *mg_version(void);

/* Open from memory. utf16=true makes all offsets UTF-16 code units
 * (JavaScript, Swift NSString, Java/Kotlin, C#); false = Unicode scalars. */
MgSession *mg_open(const uint8_t *data, size_t len, const char *password, bool utf16, char **err);
/* Open from a file path: the file is read in place as pages/chapters are
 * needed (only indexes stay in memory); keep it in place while open. */
MgSession *mg_open_path(const char *path, const char *password, bool utf16, char **err);
void mg_close(MgSession *s);

/* JSON-RPC style call; *out receives the result or {"error":{...}}. */
bool mg_call(MgSession *s, const char *method, const char *args_json, char **out);

/* Methods that need no document: the note link grammar (noteParse,
 * noteSerialize, noteTargets, notePlainText) and version. Same contract as mg_call. */
bool mg_call_static(const char *method, const char *args_json, char **out);

/* EPUB resources (images, fonts, sanitised CSS). */
uint8_t *mg_resource(MgSession *s, const char *path, size_t *len, char **media_type);

/* OCR (requires the library built with the `ocrs` feature). */
bool mg_load_ocr(MgSession *s, const uint8_t *det, size_t det_len, const uint8_t *rec, size_t rec_len, char **err);
bool mg_ocr_rgba(MgSession *s, size_t unit, uint32_t width, uint32_t height, const uint8_t *rgba, float scale, char **out);

void mg_free_string(char *p);
void mg_free_bytes(uint8_t *p, size_t len);

#ifdef __cplusplus
}
#endif
#endif
